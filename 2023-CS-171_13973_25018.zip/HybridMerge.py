import time
import csv
import random

def RandomArray(size):
    return [random.randint(1, 100000) for _ in range(size)]


def Merge(array, p, q, r):
    left = array[p:q+1]
    right = array[q+1:r+1]
    i = j = 0
    k = p
    while i < len(left) and j < len(right):
        if left[i] <= right[j]:
            array[k] = left[i]
            i += 1
        else:
            array[k] = right[j]
            j += 1
        k += 1
    while i < len(left):
        array[k] = left[i]
        i += 1
        k += 1
    while j < len(right):
        array[k] = right[j]
        j += 1
        k += 1

def InsertionSort(array, start, end):
    for i in range(start+1, end):
        temp = array[i]
        j = i - 1
        while j >= 0 and array[j] > temp:
            array[j+1] = array[j]
            j -= 1
        array[j+1] = temp
    return array

def HybridMergeSort(array, start, end, threshold=50):
    if end - start <= threshold:
        InsertionSort(array, start, end)
    else:
        mid = (start + end) // 2
        HybridMergeSort(array, start, mid)
        HybridMergeSort(array, mid+1, end)
        Merge(array, start, mid, end)

array = RandomArray(30000)
start_time = time.time()
HybridMergeSort(array, 0, len(array)-1)
end_time = time.time()

with open('RunTime.csv', 'a', newline='') as f:
    writer = csv.writer(f)
    writer.writerow(["Hybrid Merge Sort", end_time - start_time])
print(f"Hybrid Merge Sort runtime: {end_time - start_time} seconds")

with open('SortedHybridSort.csv', 'w', newline='') as f:
    writer = csv.writer(f)
    writer.writerows([[num] for num in array])
