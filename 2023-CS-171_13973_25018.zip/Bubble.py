import time
import random
import csv

def RandomArray(size):
    return [random.randint(1, 100000) for _ in range(size)]

def BubbleSort(array, start, end):
    for i in range(start, end):
        for j in range(start, end - i - 1):
            if array[j] > array[j+1]:
                array[j], array[j+1] = array[j+1], array[j]
    return array

array = RandomArray(30000)
start_time = time.time()
BubbleSort(array, 0, len(array))
end_time = time.time()
print(f"Bubble Sort runtime: {end_time - start_time} seconds")

with open('SortedBubbleSort.csv', 'w', newline='') as f:
    writer = csv.writer(f)
    writer.writerows([[num] for num in array])