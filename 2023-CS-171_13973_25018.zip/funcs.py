import random

def RandomArray(size):
    return [random.randint(1, 100000) for _ in range(size)]