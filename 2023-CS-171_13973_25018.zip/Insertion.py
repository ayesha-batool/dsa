import time
import csv
import random

def RandomArray(size):
    return [random.randint(1, 100000) for _ in range(size)]

def InsertionSort(array, start, end):
    for i in range(start+1, end):
        temp = array[i]
        j = i - 1
        while j >= 0 and array[j] > temp:
            array[j+1] = array[j]
            j -= 1
        array[j+1] = temp
    return array

array = RandomArray(30000)
start_time = time.time()
sorted_array = InsertionSort(array, 0, len(array))
end_time = time.time()

with open('RunTime.csv', 'a', newline='') as f:
    writer = csv.writer(f)
    writer.writerow(["Insertion Sort", end_time - start_time])

print(f"Insertion Sort runtime: {end_time - start_time} seconds")

with open('SortedInsertionSort.csv', 'w', newline='') as f:
    writer = csv.writer(f)
    writer.writerows([[num] for num in sorted_array])
