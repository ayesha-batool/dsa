import time
import random
import csv

def RandomArray(size):
    return [random.randint(1, 100000) for _ in range(size)]

def SelectionSort(array, start, end):
    for i in range(start, end):
        minIdx = i
        for j in range(i+1, end):
            if array[j] < array[minIdx]:
                minIdx = j
        array[i], array[minIdx] = array[minIdx], array[i]
    return array

array = RandomArray(30000)
start_time = time.time()
SelectionSort(array, 0, len(array))
end_time = time.time()

print(f"Selection Sort runtime: {end_time - start_time} seconds")


with open('RunTime.csv', 'a', newline='') as f:
    writer = csv.writer(f)
    writer.writerow(["Sorted Selection Sort", end_time - start_time])

with open('SortedSelectionSort.csv', 'w', newline='') as f:
    writer = csv.writer(f)
    writer.writerows([[num] for num in array])
