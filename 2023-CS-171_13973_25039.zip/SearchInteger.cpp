#include <iostream>
#include <vector>
using namespace std;

int main() {
    vector<int> vec = {10, 20, 30, 40, 50};
    int search_val;
    
    cout << "Enter the number to search: ";
    cin >> search_val;
    
    for (int i = 0; i < vec.size(); ++i) {
        if (vec[i] == search_val) {
            cout << "Found at index " << i << endl;
            return 0;
        }
    }
    cout << "Element not found.\n";
    return 0;
}
