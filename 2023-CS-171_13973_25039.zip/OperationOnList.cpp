numbers = [5, -1, -8, 7, 10, 15, -3]

# Remove negative numbers
positive_numbers = [x for x in numbers if x >= 0]
print("Without negatives:", positive_numbers)

# Find max and min
print("Max value:", max(positive_numbers))
print("Min value:", min(positive_numbers))

# Compute average
print("Average:", sum(positive_numbers) / len(positive_numbers))
