#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {
    vector<string> vec;
    string input;
    int choice;
    
    do {
        cout << "1. Add string\n2. Remove last string\n3. Display size and capacity\n4. Display all strings\n5. Exit\n";
        cout << "Choose an option: ";
        cin >> choice;
        
        switch(choice) {
            case 1:
                cout << "Enter string: ";
                cin >> input;
                vec.push_back(input);
                break;
            case 2:
                if (!vec.empty()) vec.pop_back();
                else cout << "Vector is empty!\n";
                break;
            case 3:
                cout << "Size: " << vec.size() << ", Capacity: " << vec.capacity() << endl;
                break;
            case 4:
                for (auto &s : vec) cout << s << " ";
                cout << endl;
                break;
        }
    } while (choice != 5);
    return 0;
}
