grid = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]

# Add a new row
grid.append([10, 11, 12])

# Add a new column
for row in grid:
    row.append(len(row) + 1)

# Display the grid
print("Grid:")
for row in grid:
    print(row)

# Sum of all elements
total_sum = sum(sum(row) for row in grid)
print("Sum of all elements:", total_sum)
