students = []

def display_students():
    print("Student List:", students)

while True:
    print("\n1. Add Student\n2. Remove Student\n3. Display Students\n4. Exit")
    choice = int(input("Choose an option: "))
    
    if choice == 1:
        name = input("Enter student name: ")
        students.append(name)
    elif choice == 2:
        name = input("Enter student name to remove: ")
        if name in students:
            students.remove(name)
        else:
            print("Student not found!")
    elif choice == 3:
        display_students()
    elif choice == 4:
        break
    else:
        print("Invalid option!")
