#include <iostream>
#include <vector>
#include <algorithm>
#include <set>
using namespace std;

int main() {
    vector<int> vec = {30, 10, 50, 20, 40, 30};
    
    // Reverse the elements
    reverse(vec.begin(), vec.end());
    cout << "Reversed: ";
    for (int x : vec) cout << x << " ";
    cout << endl;

    // Sort in ascending order
    sort(vec.begin(), vec.end());
    cout << "Sorted: ";
    for (int x : vec) cout << x << " ";
    cout << endl;
    
    // Remove duplicates
    set<int> s(vec.begin(), vec.end());
    vec.assign(s.begin(), s.end());
    cout << "After removing duplicates: ";
    for (int x : vec) cout << x << " ";
    cout << endl;

    return 0;
}
