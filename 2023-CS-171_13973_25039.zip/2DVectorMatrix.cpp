#include <iostream>
#include <vector>
using namespace std;

void displayMatrix(vector<vector<int>> &matrix) {
    for (auto &row : matrix) {
        for (int val : row) cout << val << " ";
        cout << endl;
    }
}

int main() {
    vector<vector<int>> matrix(3, vector<int>(3, 0)); // 3x3 matrix initialized to 0
    matrix[1][1] = 5;
    matrix.push_back({4, 5, 6}); // Adding a new row

    cout << "Matrix:\n";
    displayMatrix(matrix);
    
    return 0;
}
