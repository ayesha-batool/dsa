import time

my_list = []
start_time = time.time()

for i in range(1, 101):
    my_list.append(i)
    print(f"Appending {i}, Time elapsed: {time.time() - start_time:.6f} seconds")

print("Final List:", my_list)
