# P1
x=input("Enter the number: ")
y=int(x)
arr=[22,2,1,7,11,13,5,2,9]
found=[]
i=0
def search(arr,y,i,found):
    if(i<len(arr)):
        
        if(arr[i]==y):
            found.append(i)
        return(search(arr,y,i+1,found))
    return "Index: ",found
print(search(arr,y,i,found))

# P2
# In the sorted array, using binary search, you reduce the number of checks to 𝑂(log ⁡𝑛)O(logn), as you search for the first occurrence and then scan adjacent elements.
arr.sort()
print(arr)
def searchB(arr,y):
    mid=int((len(arr)-1)/2)
    for  i in arr:
        if(arr[mid]==y):
            return mid
        if(arr[mid]<y):
             mid+=1
        if(arr[mid]>y):
             mid-=1      
print(searchB(arr,y))

# P3
arr=[]
for i in range(10):
    elem=int(input("Enter elements for array: "))
    arr.append(elem)
StaringInd=int(input("Staring Index: "))
EndingInd=int(input("Ending Index: "))
arrB=arr[StaringInd:EndingInd]
def Minimum(arrB):
    min=arrB[0]
    for i,val in enumerate(arrB):
        if(min>arrB[i]):           
            min=arrB[i]
    return min        
print(Minimum(arrB))

# P4
arrA=[]
arr = [23, -23, 2, 0, 12, 5432, 54, 14, 324, 1301]       
def sort4(arr,arrA):
        min = arr[0]
        for j in arr:
            if min > j:
                min = j
        arrA.append(min)    
        while min in arr:
            arr.remove(min)
        if(len(arr)!=0):
            return sort4(arr,arrA)
        else:
            return arrA    
print(sort4(arr,arrA))
       
# P5
s = "University of Engineering and Technology Lahore"
starting=int(input("Starting: "))
ending=int(input("Ending: "))
def StringReverse(s,staring,ending):
    arrA=s[starting:ending]
    return(arrA[ ::-1])
print(StringReverse(s,starting,ending))

# P6
def SumIterative(no):
    sum=0
    s=str(no)
    arr=list(s)
    for i in arr:
        sum+=int(i)
    return "Sum of digits is: ",sum 
print(SumIterative(1524))    
    
def SumRecursive(no):
    
    if(no!=0):
        return no%10+SumRecursive(no//10)
    return 0
print(SumRecursive(1524))   
   
# P7
A=[[1,13,13],[5,11,6],[4,4,9]]
def RowWiseSum(A):
    for i in A:
      print(i[0]+i[1]+i[2])
          
def ColumnWiseSum(A):
  for k in range(3):
    sumCol=0
    for i in range(3):
        sumCol+=A[i][k]
    print(sumCol)
print(RowWiseSum(A))
print(ColumnWiseSum(A))  

# P8
def SortedMerge(A, B):
    sorted_array = []
    i, j = 0, 0
    
    while i < len(A) and j < len(B):
        if A[i] <= B[j]:
            sorted_array.append(A[i])
            i += 1
        else:
            sorted_array.append(B[j])
            j += 1
    
    while i < len(A):
        sorted_array.append(A[i])
        i += 1    
    while j < len(B):
        sorted_array.append(B[j])
        j += 1
    
    return sorted_array

A = [0, 3, 4, 10, 11]
B = [1, 8, 13, 24]
print("Merged sorted array:", SortedMerge(A, B))

# P9
def PalindromRecursive(s):
    if len(s) <= 1:
        return True
    if s[0] != s[-1]:
        return False    
    return PalindromRecursive(s[1:-1])
s = "radar"
print("Is the string a palindrome?", PalindromRecursive(s))

# P10
def Sort10(arr):
    return sorted(arr)
arr = [10, -1, 9, 20, -3, -8, 22, 9, 7]
sorted_arr = Sort10(arr)
print("Sorted array:", sorted_arr)