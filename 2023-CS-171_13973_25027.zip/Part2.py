import pandas as pd

data_url = 'https://bit.ly/3DbA7Ee'
data = pd.read_csv(data_url)
print(data.head())
import matplotlib.pyplot as plt
for symptom in data.columns[:-1]:  
    plt.figure(figsize=(10, 5))
    plt.scatter(data[symptom], data['label'], alpha=0.5)
    plt.title(f'Scatter plot between {symptom} and label')
    plt.xlabel(symptom)
    plt.ylabel('Label')
    plt.show()

import numpy as np
test_data_url = 'https://bit.ly/3D7FQv4'
test_data = pd.read_csv(test_data_url)
def euclidean_distance(x, y):
    return np.sqrt(np.sum((x - y) ** 2))
distances = []
labels = []

for _, test_row in test_data.iterrows():
    min_distance = float('inf')
    assigned_label = None
    for _, train_row in data.iterrows():
        distance = euclidean_distance(test_row[:-1], train_row[:-1]) 
        if distance < min_distance:
            min_distance = distance
            assigned_label = train_row['label']
    
    distances.append(min_distance)
    labels.append(assigned_label)

test_data['assigned_label'] = labels
part1 = data.copy()  
part2 = data.drop(columns=['label'])  
correct_count = 0
total_count = len(part2)
for _, test_row in part2.iterrows():
    min_distance = float('inf')
    assigned_label = None
    for _, train_row in part1.iterrows():
        distance = euclidean_distance(test_row, train_row[:-1]) 
        if distance < min_distance:
            min_distance = distance
            assigned_label = train_row['label']
    
    if assigned_label == test_row['assigned_label']: 
        correct_count += 1

accuracy = (correct_count / total_count) * 100
print(f'Accuracy: {accuracy}%')
def recursive_distance(train_data, test_row, index=0, min_distance=float('inf'), assigned_label=None):
    if index >= len(train_data):
        return min_distance, assigned_label
    distance = euclidean_distance(test_row, train_data.iloc[index][:-1])  
    if distance < min_distance:
        min_distance = distance
        assigned_label = train_data.iloc[index]['label']
    return recursive_distance(train_data, test_row, index + 1, min_distance, assigned_label)
from sklearn.neighbors import KNeighborsClassifier
X_train = part1.drop(columns=['label'])
y_train = part1['label']
X_test = part2
knn = KNeighborsClassifier(n_neighbors=1)  
knn.fit(X_train, y_train)
predictions = knn.predict(X_test)
correct_predictions = (predictions == y_train.values).sum()
accuracy_improved = (correct_predictions / len(X_test)) * 100
print(f'Improved Accuracy: {accuracy_improved}%')
