import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd
df = pd.read_csv('population_by_country_2020.csv' )
print(df.dtypes)
list1 = df['Country (or dependency)'].values.tolist()
list2 = df['Population (2020)'].values.tolist()
plt.bar(list1, list2,width = 1, color = ['red', 'green'])

# line  chart for total steps
df_steps = pd.read_csv('dailySteps_merged.csv')
df_steps['ActivityDay'] = pd.to_datetime(df_steps['ActivityDay'])
plt.figure(figsize=(10, 10))
plt.plot(df_steps['ActivityDay'], df_steps['StepTotal'], marker='.', linestyle='-', color='g')
plt.title('Total Number of Steps on Daily Basis')
plt.xlabel('Date')
plt.ylabel('Total Steps')
plt.xticks(rotation=45)
plt.savefig('daily_steps_plot.png')

# bar chart for total distance covered
df = pd.read_csv('dailyActivity_merged.csv')
df['ActivityDate'] = pd.to_datetime(df['ActivityDate'])
df.set_index('ActivityDate', inplace=True)
plt.figure(figsize=(12, 6))
plt.bar(df.index, df['TotalDistance'], color='blue')
plt.title('Daily Distance Covered')
plt.xlabel('Date')
plt.ylabel('Total Distance (Km)')
plt.savefig('daily_distance_covered.png')  

# scatter chart for sleep time
df = pd.read_csv('sleepDay_merged.csv')
df['SleepDay'] = pd.to_datetime(df['SleepDay'], format='%m/%d/%Y %I:%M:%S %p')
df.set_index('SleepDay', inplace=True)
plt.figure(figsize=(12, 6))
plt.scatter(df.index, df['TotalTimeInBed'], color='purple', alpha=0.5)
plt.title('Total Time in Bed')
plt.xlabel('Date')
plt.ylabel('Total Time in Bed (Minutes)')
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig('total_time_in_bed.png')

# pie chart for hourly steps
df = pd.read_csv('hourlySteps_merged.csv')
df['ActivityHour'] = pd.to_datetime(df['ActivityHour'], format='%m/%d/%Y %I:%M:%S %p')
df_filtered = df[df['ActivityHour'].dt.date == pd.to_datetime('2016-04-12').date()]
if df_filtered.empty:
    print("No data available for April 12, 2016.")
else:
    threshold = 100  
    df_filtered['StepCategory'] = df_filtered['StepTotal'].apply(lambda x: 'Other' if x < threshold else x)
    agg_df = df_filtered.groupby('StepCategory')['StepTotal'].sum().reset_index()
    plt.figure(figsize=(10, 10))
    colors = plt.cm.tab10.colors  
    plt.pie(agg_df['StepTotal'], labels=agg_df['StepCategory'].astype(str), autopct='%1.1f%%', startangle=90, colors=colors)
    plt.title('Hourly Steps on April 12, 2016')
    plt.axis('equal')  
    plt.show()

