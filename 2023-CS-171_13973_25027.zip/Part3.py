def printMatrix(A, starting_index, rows, columns):
    x, y = starting_index
    for i in range(rows):
        for j in range(columns):
            print(A[x + i][y + j], end=' ')
        print()  

 
A = [[1, 2, 3, 4, 5],
     [6, 7, 8, 9, 10],
     [11, 12, 13, 14, 15],
     [16, 17, 18, 19, 20]]
printMatrix(A, (1, 1), 2, 3)  

def MatAdd(A, B):
    rows = len(A)
    cols = len(A[0])
    result = [[0 for _ in range(cols)] for _ in range(rows)]
    for i in range(rows):
        for j in range(cols):
            result[i][j] = A[i][j] + B[i][j]
    return result

 
A = [[1, 2, 3],
     [4, 5, 6]]
B = [[7, 8, 9],
     [1, 2, 3]]
print(MatAdd(A, B))  


def MatAddPartial(A, B, start, size):
    x, y = start
    result = [[0 for _ in range(size)] for _ in range(size)]
    for i in range(size):
        for j in range(size):
            result[i][j] = A[x + i][y + j] + B[x + i][y + j]
    return result

 
A = [[1, 2, 3, 4],
     [5, 6, 7, 8],
     [9, 10, 11, 12],
     [13, 14, 15, 16]]
B = [[1, 1, 1, 1],
     [2, 2, 2, 2],
     [3, 3, 3, 3],
     [4, 4, 4, 4]]
print(MatAddPartial(A, B, (1, 1), 2))  

def MatMul(A, B):
    rows_A = len(A)
    cols_A = len(A[0])
    cols_B = len(B[0])
    
    result = [[0 for _ in range(cols_B)] for _ in range(rows_A)]
    
    for i in range(rows_A):
        for j in range(cols_B):
            for k in range(cols_A):
                result[i][j] += A[i][k] * B[k][j]
    return result

 
A = [[1, 2],
     [3, 4]]
B = [[5, 6],
     [7, 8]]
print(MatMul(A, B))  

def MatMulRecursive(A, B):
    def multiply_recursive(A, B, result, row_A, col_A, row_B, col_B):
        if row_A == len(A) or col_B == len(B):
            return
        if col_A < len(A[0]):
            result[row_A][col_B] += A[row_A][col_A] * B[col_A][col_B]
            multiply_recursive(A, B, result, row_A, col_A + 1, row_B, col_B)
        else:
            multiply_recursive(A, B, result, row_A + 1, 0, row_B, col_B + 1)
    
    rows_A = len(A)
    cols_B = len(B[0])
    result = [[0 for _ in range(cols_B)] for _ in range(rows_A)]
    multiply_recursive(A, B, result, 0, 0, 0, 0)
    return result

 
A = [[1, 2],
     [3, 4]]
B = [[5, 6],
     [7, 8]]
print(MatMulRecursive(A, B)) 

def MatMulStrassen(A, B):
    def add_matrix(A, B):
        return [[A[i][j] + B[i][j] for j in range(len(A[0]))] for i in range(len(A))]
    
    def subtract_matrix(A, B):
        return [[A[i][j] - B[i][j] for j in range(len(A[0]))] for i in range(len(A))]
    
    if len(A) == 1:
        return [[A[0][0] * B[0][0]]]
    
    mid = len(A) // 2
    
    A11 = [row[:mid] for row in A[:mid]]
    A12 = [row[mid:] for row in A[:mid]]
    A21 = [row[:mid] for row in A[mid:]]
    A22 = [row[mid:] for row in A[mid:]]
    
    B11 = [row[:mid] for row in B[:mid]]
    B12 = [row[mid:] for row in B[:mid]]
    B21 = [row[:mid] for row in B[mid:]]
    B22 = [row[mid:] for row in B[mid:]]
    
    M1 = MatMulStrassen(add_matrix(A11, A22), add_matrix(B11, B22))
    M2 = MatMulStrassen(add_matrix(A21, A22), B11)
    M3 = MatMulStrassen(A11, subtract_matrix(B12, B22))
    M4 = MatMulStrassen(A22, subtract_matrix(B21, B11))
    M5 = MatMulStrassen(add_matrix(A11, A12), B22)
    M6 = MatMulStrassen(subtract_matrix(A21, A11), add_matrix(B11, B12))
    M7 = MatMulStrassen(subtract_matrix(A12, A22), add_matrix(B21, B22))
    
    C11 = add_matrix(subtract_matrix(add_matrix(M1, M4), M5), M7)
    C12 = add_matrix(M3, M5)
    C21 = add_matrix(M2, M4)
    C22 = add_matrix(subtract_matrix(add_matrix(M1, M3), M2), M6)

    C = []
    for i in range(len(C11)):
        C.append(C11[i] + C12[i])
    for i in range(len(C21)):
        C.append(C21[i] + C22[i])
    
    return C
 
A = [[1, 2],
     [3, 4]]
B = [[5, 6],
     [7, 8]]
print(MatMulStrassen(A, B))  
