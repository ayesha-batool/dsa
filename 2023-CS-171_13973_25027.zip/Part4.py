from selenium import webdriver
from bs4 import BeautifulSoup
import pandas as pd
import time 

driver = webdriver.Chrome(executable_path='G:\Program Files\Anaconda3\chromdriver\chromedriver.exe')

products = []
prices = []
ratings = []

driver.get("https://www.flipkart.com/gaming-laptops-store?otracker=nmenu_sub_Electronics_0_Gaming%20Laptops&otracker=nmenu_sub_Electronics_0_Gaming%20Laptops")

time.sleep(5)  

content = driver.page_source
soup = BeautifulSoup(content, 'html.parser')

for a in soup.findAll('div', attrs={'class': '_1AtVbE'}):
    name = a.find('a', attrs={'class': 'IRpwTa'})
    price = a.find('div', attrs={'class': '_30jeq3'})
    rating = a.find('div', attrs={'class': '_3LWZlK'})

    if name and price and rating:
        products.append(name.text)
        prices.append(price.text)
        ratings.append(rating.text)

df = pd.DataFrame({'Product Name': products, 'Price': prices, 'Rating': ratings})
df.to_csv('products.csv', index=False, encoding='utf-8')

driver.quit()
