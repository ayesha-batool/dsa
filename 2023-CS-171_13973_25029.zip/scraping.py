import requests
from bs4 import BeautifulSoup

websites = [
    "https://example.com",
    "https://www.python.org",
    "https://www.wikipedia.org",
    "https://www.github.com",
    "https://www.stackoverflow.com",
    "https://www.reddit.com",
    "https://www.medium.com",
    "https://www.nytimes.com",
    "https://www.bbc.com",
    "https://www.cnn.com"
]

def scrape_website(url):
    try:
        response = requests.get(url)
        
        if response.status_code == 200:
            soup = BeautifulSoup(response.content, 'html.parser')
            
            title = soup.title.string if soup.title else 'No title found'
            
            return title
        else:
            return f"Failed to retrieve {url}: Status code {response.status_code}"
    
    except Exception as e:
        return f"Error scraping {url}: {e}"

for site in websites:
    title = scrape_website(site)
    print(f"Website: {site}\nTitle: {title}\n")
